using UnityEngine;
using UnityEngine.Rendering;

public partial class PostFxStack
{
    public enum Pass {
        BLOOMADD, BLOOMHORIZONTAL, BLOOMPREFILTER, 
        BLOOMPREFILTERFIREFLIES, BLOOMSCATTER, BLOOMVERTICAL, 
        COPY, REINHARD, NEUTRAL, ACES
    }

    private const int maxBloomPyramidLevels = 16;

    private int[] bloomIDs = new int[maxBloomPyramidLevels * 2];

    private const string bufferName = "Post FX";

    private CommandBuffer buffer = 
        new CommandBuffer { name = bufferName };

    private Camera camera;

    private bool useHDR = false;

    private ScriptableRenderContext context;

    private PostFXSettings settings;

    private static int bloomBicubicUpsamplingID = 
        Shader.PropertyToID("_BloomBicubicUpsampling");

    private static int bloomIntensityID = 
        Shader.PropertyToID("_BloomIntensity");

    private static int bloomThresholdID = 
        Shader.PropertyToID("_BloomThreshold");

    private static int fxSourceID = Shader.PropertyToID("_PostFXSource");

    private static int fxSource2ID = Shader.PropertyToID("_PostFXSource2");

    private static int bloomResultID = Shader.PropertyToID("_BloomResult");

    public bool IsActive => settings != null;

    public PostFxStack() {
        for (int i = 0; i < maxBloomPyramidLevels * 2; i++) {
            bloomIDs[i] = Shader.PropertyToID("_BloomPyramid" + i);
        }
    }

    public void Setup(ScriptableRenderContext context, 
        Camera camera, PostFXSettings settings, bool useHDR) {
        this.camera = camera;
        this.useHDR = useHDR;
        this.context = context;
        this.settings = camera.cameraType <= CameraType.SceneView ? settings : null;
        ApplySceneViewState();
    }

    private void Draw(RenderTargetIdentifier source, RenderTargetIdentifier target,
                      Pass pass) {
        buffer.SetGlobalTexture(fxSourceID, source);
        buffer.SetRenderTarget(target, 
            RenderBufferLoadAction.DontCare, RenderBufferStoreAction.Store);
        buffer.DrawProcedural(
            Matrix4x4.identity, settings.Material, 
            (int)pass, MeshTopology.Triangles, 3);
    }

    private bool Bloom(int sourceID) {
        var format = useHDR ? RenderTextureFormat.DefaultHDR : RenderTextureFormat.Default;
        int width = camera.pixelWidth / 2, height = camera.pixelHeight / 2, iter = 0;

        if (width <= settings.Bloom.downscaleLimit 
         || height <= settings.Bloom.downscaleLimit 
         || settings.Bloom.maxIterations == 0) {
            return false;
        }

        buffer.BeginSample("Bloom");
        buffer.SetGlobalFloat(bloomBicubicUpsamplingID, settings.Bloom.bicubicUpsampling ? 1.0f : 0.0f);
        buffer.SetGlobalVector(bloomThresholdID, 
            new Vector4(Mathf.GammaToLinearSpace(settings.Bloom.threshold), 
            settings.Bloom.thresholdKnee));

        for (iter = 0; iter < settings.Bloom.maxIterations; iter++) {
            if (width <= settings.Bloom.downscaleLimit 
             || height <= settings.Bloom.downscaleLimit) { break; }
            buffer.GetTemporaryRT(
                bloomIDs[2 * iter + 1], width, height, 0,
                FilterMode.Bilinear, format);
            buffer.GetTemporaryRT(
                bloomIDs[2 * iter], width, height, 0, 
                FilterMode.Bilinear, format);
            if (iter == 0) {
                Draw(sourceID, bloomIDs[1], 
                    settings.Bloom.fadeFireflies ? 
                    Pass.BLOOMPREFILTERFIREFLIES : Pass.BLOOMPREFILTER);
            } else {
                Draw(bloomIDs[2 * iter - 1], bloomIDs[2 * iter], Pass.BLOOMHORIZONTAL);
                Draw(bloomIDs[2 * iter], bloomIDs[2 * iter + 1], Pass.BLOOMVERTICAL);
            }
            width /= 2;
            height /= 2;
        }

        Pass combinePass, finalPass;
        float finalIntensity;
        if (settings.Bloom.mode == PostFXSettings.BloomSettings.Mode.Additive) {
            combinePass = finalPass = Pass.BLOOMADD;
            buffer.SetGlobalFloat(bloomIntensityID, 1.0f);
            finalIntensity = settings.Bloom.intensity;
        } else {
            combinePass = Pass.BLOOMSCATTER;
            finalPass = Pass.BLOOMADD;
            buffer.SetGlobalFloat(bloomIntensityID, settings.Bloom.scatter);
            finalIntensity = Mathf.Min(settings.Bloom.intensity, 0.95f);
        }

        for (int i = iter - 1; i >= 1; i--) {
            buffer.SetGlobalTexture(fxSource2ID, bloomIDs[2 * i - 1]);
            Draw(i >= iter - 1 ? bloomIDs[2 * i + 1] : bloomIDs[2 * i], 
                bloomIDs[2 * i - 2], combinePass);
        }
        buffer.SetGlobalFloat(bloomIntensityID, finalIntensity);
        buffer.SetGlobalTexture(fxSource2ID, sourceID);
        buffer.GetTemporaryRT(bloomResultID, camera.pixelWidth,
            camera.pixelHeight, 0, FilterMode.Bilinear, format);
        Draw(iter == 1 ? bloomIDs[1] : bloomIDs[0], bloomResultID, finalPass);

        for (iter -= 1; iter >= 0; iter--) {
            buffer.ReleaseTemporaryRT(bloomIDs[2 * iter]);
            buffer.ReleaseTemporaryRT(bloomIDs[2 * iter + 1]);
        }
        buffer.EndSample("Bloom");
        return true;
    }

    private void ToneMapping(int sourceID) {
        Pass pass = Pass.COPY + (int)settings.ToneMapping.mode;
        Draw(sourceID, BuiltinRenderTextureType.CameraTarget, pass);
    }

    public void Render(int sourceID) {
        if (Bloom(sourceID)) {
            ToneMapping(bloomResultID);
            buffer.ReleaseTemporaryRT(bloomResultID);
        } else {
            ToneMapping(sourceID);
        }
        context.ExecuteCommandBuffer(buffer);
        buffer.Clear();
    }
}
