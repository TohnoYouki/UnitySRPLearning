using UnityEngine;
using Unity.Collections;
using UnityEngine.Rendering;

public class Lighting {

    private const string bufferName = "Lighting";
    
    private CommandBuffer buffer = new CommandBuffer { name = bufferName };
    
    private CullingResults cullingResults;
    
    private Shadow shadows = new Shadow();
    
    private const int maxDirectionalLightCount = 4;

    private const int maxOtherLightCount = 64;

    private static int dirLightCountId = 
        Shader.PropertyToID("_DirectionalLightCount");

    private static int dirLightColorId = 
        Shader.PropertyToID("_DirectionalLightColors");

    private Vector4[] dirLightColors = 
        new Vector4[maxDirectionalLightCount];
    
    private static int dirLightDirectionId = 
        Shader.PropertyToID("_DirectionalLightDirections");

    private Vector4[] dirLightDirections = 
        new Vector4[maxDirectionalLightCount];

    private static int dirLightShadowDataId = 
        Shader.PropertyToID("_DirectionalLightShadowDatas");

    private Vector4[] dirLightShadowDatas = 
        new Vector4[maxDirectionalLightCount];
    
    private static int otherLightCountId = 
        Shader.PropertyToID("_OtherLightCount");

    private static int otherLightColorId = 
        Shader.PropertyToID("_OtherLightColors");

    private Vector4[] otherLightColors = 
        new Vector4[maxOtherLightCount];

    private static int otherLightPositionId = 
        Shader.PropertyToID("_OtherLightPositions");

    private Vector4[] otherLightPositions = 
        new Vector4[maxOtherLightCount];

    private static int otherLightDirectionId = 
        Shader.PropertyToID("_OtherLightDirections");

    private Vector4[] otherLightDirections =
        new Vector4[maxOtherLightCount];

    private static int otherLightSpotAngleId =
        Shader.PropertyToID("_OtherLightSpotAngles");

    private Vector4[] otherLightSpotAngles = 
        new Vector4[maxOtherLightCount];
    
    private static int otherLightShadowDataId = 
        Shader.PropertyToID("_OtherLightShadowDatas");

    private Vector4[] otherLightShadowDatas = 
        new Vector4[maxOtherLightCount];

    private static string lightPerObjectKeyword = "_LIGHTS_PER_OBJECT";

    private void SetupDirectionalLight(int index, int visibleLightIndex, ref VisibleLight light) {
        dirLightColors[index] = light.finalColor;
        dirLightDirections[index] = -light.localToWorldMatrix.GetColumn(2);
        dirLightShadowDatas[index] = shadows.ReserveDirectionalShadows(light.light, visibleLightIndex);
    }

    private void SetupPointLight(int index, int visibleLightIndex, ref VisibleLight light) {
        otherLightColors[index] = light.finalColor;
        otherLightPositions[index] = light.localToWorldMatrix.GetColumn(3);
        otherLightPositions[index].w = 1.0f / Mathf.Max(light.range * light.range, 1e-5f);
        otherLightSpotAngles[index] = new Vector4(0.0f, 1.0f);
        otherLightShadowDatas[index] = shadows.ReserveOtherShadows(light.light, visibleLightIndex);
    }

    private void SetupSpotLight(int index, int visibleLightIndex, ref VisibleLight light) {
        otherLightColors[index] = light.finalColor;
        otherLightPositions[index] = light.localToWorldMatrix.GetColumn(3);
        otherLightPositions[index].w = 1.0f / Mathf.Max(light.range * light.range, 1e-5f);
        otherLightDirections[index] = -light.localToWorldMatrix.GetColumn(2); 
		float innerCos = Mathf.Cos(Mathf.Deg2Rad * 0.5f * light.light.innerSpotAngle);
		float outerCos = Mathf.Cos(Mathf.Deg2Rad * 0.5f * light.spotAngle);
		float angleRangeInv = 1f / Mathf.Max(innerCos - outerCos, 0.001f);
		otherLightSpotAngles[index] = new Vector4(angleRangeInv, -outerCos * angleRangeInv); 
        otherLightShadowDatas[index] = shadows.ReserveOtherShadows(light.light, visibleLightIndex);
    }
    
    private void SetupLights(bool useLightPerObject) {
        NativeArray<int> lightIndexMap = useLightPerObject ? 
            cullingResults.GetLightIndexMap(Allocator.Temp) : default;
        NativeArray<VisibleLight> visibleLights = cullingResults.visibleLights;
        
        int otherLightCount = 0, dirLightCount = 0;
        for (int i = 0; i < visibleLights.Length; i++) {
            int newIndex = -1;
            VisibleLight light = visibleLights[i]; 
            switch (light.lightType) {
                case LightType.Directional:
                    if (dirLightCount < maxDirectionalLightCount) {
                        SetupDirectionalLight(dirLightCount++, i, ref light);
                    }
                    break;
                case LightType.Point:
                    if (otherLightCount < maxOtherLightCount) {
                        newIndex = otherLightCount;
                        SetupPointLight(otherLightCount++, i, ref light);
                    }
                    break;
                case LightType.Spot:
                    if (otherLightCount < maxOtherLightCount) {
                        newIndex = otherLightCount;
                        SetupSpotLight(otherLightCount++, i, ref light);
                    }
                    break;
            }
            if (useLightPerObject) { lightIndexMap[i] = newIndex; }
        }

        if (useLightPerObject) {
            for (int i = visibleLights.Length; i < lightIndexMap.Length; i++) {
                lightIndexMap[i] = -1;
            }
            cullingResults.SetLightIndexMap(lightIndexMap);
            lightIndexMap.Dispose();
            Shader.EnableKeyword(lightPerObjectKeyword);
        } else {
            Shader.DisableKeyword(lightPerObjectKeyword);
        }

        buffer.SetGlobalInt(dirLightCountId, dirLightCount);
        if (dirLightCount > 0) {
            buffer.SetGlobalVectorArray(dirLightColorId, dirLightColors);
            buffer.SetGlobalVectorArray(dirLightDirectionId, dirLightDirections);
            buffer.SetGlobalVectorArray(dirLightShadowDataId, dirLightShadowDatas);
        }
        buffer.SetGlobalInt(otherLightCountId, otherLightCount);
        if (otherLightCount > 0) {
            buffer.SetGlobalVectorArray(otherLightColorId, otherLightColors);
            buffer.SetGlobalVectorArray(otherLightPositionId, otherLightPositions);
            buffer.SetGlobalVectorArray(otherLightDirectionId, otherLightDirections);
            buffer.SetGlobalVectorArray(otherLightSpotAngleId, otherLightSpotAngles);
            buffer.SetGlobalVectorArray(otherLightShadowDataId, otherLightShadowDatas);
        }
    }
    
    public void Setup(ScriptableRenderContext context, CullingResults cullingResults, 
        ShadowSettings shadowSettings, bool useLightPerObject) {
        this.cullingResults = cullingResults;
        buffer.BeginSample(bufferName);
        shadows.Setup(context, cullingResults, shadowSettings);
        SetupLights(useLightPerObject);
        shadows.Render();
        buffer.EndSample(bufferName);
        context.ExecuteCommandBuffer(buffer);
        buffer.Clear();
    }

    public void Cleanup() {
        shadows.Cleanup();
    }
}
