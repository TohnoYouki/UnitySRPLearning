using UnityEngine;

[CreateAssetMenu(menuName = "Rendering/Custom Post FX Settings")]
public class PostFXSettings : ScriptableObject {
    [SerializeField]
    public Shader shader = default;

    [System.NonSerialized]
    private Material material;

    [System.Serializable]
    public struct BloomSettings {
        public enum Mode { Additive, Scattering }

        public Mode mode;

        [Range(0.05f, 0.95f)]
        public float scatter;

        [Range(0f, 16f)]
        public int maxIterations;

        [Min(1f)]
        public int downscaleLimit;

        public bool bicubicUpsampling;

        public bool fadeFireflies;

        [Min(0f)]
        public float intensity;

        [Min(0f)]
        public float threshold;

        [Range(0f, 1f)]
        public float thresholdKnee;
    }

    [System.Serializable]
    public struct ToneMappingSettings {
        public enum Mode { None, Reinhard, Neutral, ACES }

        public Mode mode;
    }

    [SerializeField]
    private BloomSettings bloom = new BloomSettings {
        scatter = 0.7f
    };

    public BloomSettings Bloom => bloom;

    [SerializeField]
    private ToneMappingSettings toneMapping = default;

    public ToneMappingSettings ToneMapping => toneMapping;

    public Material Material {
        get {
            if (material == null && shader != null) {
                material = new Material(shader);
                material.hideFlags = HideFlags.HideAndDontSave;
            }
            return material;
        }
    }
}
