using System.ComponentModel;
using UnityEngine;
using UnityEngine.Rendering;

public class Shadow {
    
    private const string bufferName = "Shadows";
    
    private CommandBuffer buffer = new CommandBuffer{ name = bufferName };

    private bool useShadowMask = false;
    
    private ScriptableRenderContext context;
    
    private CullingResults cullingResults;
    
    private ShadowSettings shadowSettings;
    
    private const int maxShadowedDirectionalLightCount = 4;

    private const int maxDirectionalLightCascadeCount = 4;

    private struct ShadowedDirectionalLight {
        public int visibleLightIndex;
        public float slopeScaleBias;
        public float nearPlaneOffset;
    }

    private int shadowedDirectionalLightCount = 0;

    private ShadowedDirectionalLight[] shadowedDirectionalLights = 
        new ShadowedDirectionalLight[maxShadowedDirectionalLightCount];

    private static int dirShadowAtlasId = 
        Shader.PropertyToID("_DirectionalShadowAtlas");

    private static int dirShadowMatricesId = 
        Shader.PropertyToID("_DirectionalShadowMatrices");

    private static int dirShadowCascadeCountId =
        Shader.PropertyToID("_DirectionalShadowCascadeCount");

    private static int dirShadowCascadeCullingSpheresId =
        Shader.PropertyToID("_DirectionalShadowCascadeCullingSpheres");

    private static int dirShadowCascadeDataid = 
        Shader.PropertyToID("_DirectionalShadowCascadeData");

    private static int shadowAtlasSizeID = 
        Shader.PropertyToID("_ShadowAtlasSize");

    private static int shadowFadeId = 
        Shader.PropertyToID("_ShadowFade");

    private static string[] dirShadowPcfFilterKeywords = {
        "_DIRECTIONAL_PCF3", "_DIRECTIONAL_PCF5", "_DIRECTIONAL_PCF7"
    };

    private static string[] dirShadowCascadeBlendKeywords = {
        "_CASCADE_BLEND_DITHER", "_CASCADE_BLEND_SOFT"
    };

    private Vector4[] dirShadowCascadeCullingSpheres = 
        new Vector4[maxDirectionalLightCascadeCount];

    private Vector4[] dirShadowCascadeDatas = 
        new Vector4[maxDirectionalLightCascadeCount];
    
    private Matrix4x4[] dirShadowMatrices = new Matrix4x4[
        maxShadowedDirectionalLightCount * maxDirectionalLightCascadeCount];

    private const int maxShadowedOtherLightCount = 16;

    private struct ShadowedOtherLight {
        public int visibleLightIndex;
        public float slopeScaleBias;
        public float normalBias;
        public bool isPoint;
    }

    private int shadowedOtherLightCount = 0;
    
    private ShadowedOtherLight[] shadowedOtherLights = 
        new ShadowedOtherLight[maxShadowedOtherLightCount];

    private static int otherShadowAtlasId = 
        Shader.PropertyToID("_OtherShadowAtlas");

    private static int otherShadowMatricesId = 
        Shader.PropertyToID("_OtherShadowMatrices");

    private static string[] otherShadowPcfFilterKeywords = {
        "_OTHER_PCF3", "_OTHER_PCF5", "_OTHER_PCF7"
    };

    private Matrix4x4[] otherShadowMatrices = 
        new Matrix4x4[maxShadowedOtherLightCount];

    private static int otherShadowDataId = 
        Shader.PropertyToID("_OtherShadowDatas");

    private Vector4[] otherShadowDatas = 
        new Vector4[maxShadowedOtherLightCount];

    private static string[] shadowMaskKeywords = {
        "_SHADOW_MASK_ALWAYS", "_SHADOW_MASK_DISTANCE"
    };

    private static int shadowPancakingId =
        Shader.PropertyToID("_ShadowPancaking");

    private Vector4 atlasSizes;

	private void ExecuteBuffer () {
		context.ExecuteCommandBuffer(buffer);
		buffer.Clear();
	}
    
    public void Setup(ScriptableRenderContext context,
        CullingResults cullingResults, ShadowSettings shadowSettings) {
        this.context = context;
        this.cullingResults = cullingResults;
        this.shadowSettings = shadowSettings;
        this.shadowedDirectionalLightCount = 0;
        this.shadowedOtherLightCount = 0;
    }
    
    public Vector4 ReserveDirectionalShadows(Light light, int visibleLightIndex) {
        if (shadowedDirectionalLightCount < maxShadowedDirectionalLightCount &&
            light.shadows != LightShadows.None && light.shadowStrength > 0) {
            float maskChannel = -1f;
            LightBakingOutput bakingOutput = light.bakingOutput;
            if (bakingOutput.lightmapBakeType == LightmapBakeType.Mixed &&
                bakingOutput.mixedLightingMode == MixedLightingMode.Shadowmask) {
                useShadowMask = true;
                maskChannel = bakingOutput.occlusionMaskChannel;
            }
            if (!cullingResults.GetShadowCasterBounds(
                    visibleLightIndex, out Bounds bounds)) {
                return new Vector4(-light.shadowStrength, 0f, 0f, maskChannel);
            }

            shadowedDirectionalLights[shadowedDirectionalLightCount] = 
                new ShadowedDirectionalLight { 
                    visibleLightIndex = visibleLightIndex,
                    slopeScaleBias = light.shadowBias,
                    nearPlaneOffset = light.shadowNearPlane
                };
            int index = shadowedDirectionalLightCount * shadowSettings.directional.cascadeCount;
            shadowedDirectionalLightCount++;
            return new Vector4(light.shadowStrength, index, light.shadowNormalBias, maskChannel);
        }
        return new Vector4(0.0f, 0.0f, 0.0f, -1f);
    }

    public Vector4 ReserveOtherShadows(Light light, int visibleLightIndex) {
        if (light.shadows != LightShadows.None && light.shadowStrength > 0) {
            float maskChannel = -1f;
            LightBakingOutput bakingOutput = light.bakingOutput;
            if (bakingOutput.lightmapBakeType == LightmapBakeType.Mixed &&
                bakingOutput.mixedLightingMode == MixedLightingMode.Shadowmask) {
                useShadowMask = true;
                maskChannel = bakingOutput.occlusionMaskChannel;        
            }
            bool isPoint = light.type == LightType.Point;
            int newLightCount = shadowedOtherLightCount + (isPoint ? 6 : 1);
            if (newLightCount > maxShadowedOtherLightCount ||
                !cullingResults.GetShadowCasterBounds(visibleLightIndex, out Bounds bounds)) {
                return new Vector4(-light.shadowStrength, 0f, 0f, maskChannel);
            }
            shadowedOtherLights[shadowedOtherLightCount] = 
                new ShadowedOtherLight { 
                    visibleLightIndex = visibleLightIndex,
                    slopeScaleBias = light.shadowBias,
                    normalBias = light.shadowNormalBias,
                    isPoint = isPoint
                };
            Vector4 result = new Vector4(light.shadowStrength, shadowedOtherLightCount, 
                                         isPoint ? 1f : 0f, maskChannel);
            shadowedOtherLightCount = newLightCount;
            return result;
        }
        return new Vector4(0.0f, 0.0f, 0.0f, -1f);
    }

    private Rect GetShadowMapRect(int index, int count, int size) {
        int split = count <= 1 ? 1 : (count <= 4 ? 2 : 4);
        size = size / split;
        Vector2 offset = new Vector2(index % split, index / split);
        return new Rect(offset.x * size, offset.y * size, size, size);
    }

    private Matrix4x4 GetShadowMapMatrix(
        Matrix4x4 viewMatrix, Matrix4x4 projMatrix, Rect rect, int size) {
        Matrix4x4 m = projMatrix * viewMatrix;
        if (SystemInfo.usesReversedZBuffer) {
            m.m20 = -m.m20;
            m.m21 = -m.m21;
            m.m22 = -m.m22;
            m.m23 = -m.m23;
        }
        Vector2 scale = new Vector2(rect.width / size, rect.height / size);
        Vector2 offset = new Vector2(rect.x / size, rect.y / size);
		m.m00 = 0.5f * (m.m00 + m.m30) * scale.x + offset.x * m.m30;
		m.m01 = 0.5f * (m.m01 + m.m31) * scale.x + offset.x * m.m31;
		m.m02 = 0.5f * (m.m02 + m.m32) * scale.x + offset.x * m.m32;
		m.m03 = 0.5f * (m.m03 + m.m33) * scale.x + offset.x * m.m33;
		m.m10 = 0.5f * (m.m10 + m.m30) * scale.y + offset.y * m.m30;
		m.m11 = 0.5f * (m.m11 + m.m31) * scale.y + offset.y * m.m31;
		m.m12 = 0.5f * (m.m12 + m.m32) * scale.y + offset.y * m.m32;
		m.m13 = 0.5f * (m.m13 + m.m33) * scale.y + offset.y * m.m33;
		m.m20 = 0.5f * (m.m20 + m.m30);
		m.m21 = 0.5f * (m.m21 + m.m31);
		m.m22 = 0.5f * (m.m22 + m.m32);
		m.m23 = 0.5f * (m.m23 + m.m33);
        return m;  
    }

    private void SetDirectionalShadowCascadeData(int index, Vector4 sphere, int resolution) {
        float texelSize = 2f * sphere.w / resolution;
        texelSize *= ((float)shadowSettings.directional.filterMode + 1);
        sphere.w -= texelSize;
        sphere.w *= sphere.w;
        dirShadowCascadeCullingSpheres[index] = sphere;
        dirShadowCascadeDatas[index] = new Vector4(
            1f / sphere.w, texelSize * Mathf.Sqrt(2)
        );
    }

    private void RenderDirectionalShadows(int index) {
        int size = (int)shadowSettings.directional.atlasSize;
        var light = shadowedDirectionalLights[index];
        int cascade = shadowSettings.directional.cascadeCount;
        Vector3 ratio = shadowSettings.directional.CascadeRatios;

        for (int i = 0; i < cascade; i++) {
            int subIndex = index * cascade + i;
            Rect rect = GetShadowMapRect(subIndex, shadowedDirectionalLightCount 
                * shadowSettings.directional.cascadeCount, size);
            int resolution = (int)Mathf.Min(rect.width, rect.height);
            cullingResults.ComputeDirectionalShadowMatricesAndCullingPrimitives(
                light.visibleLightIndex, i, cascade, ratio, resolution, 
                light.nearPlaneOffset, out Matrix4x4 viewMatrix, 
                out Matrix4x4 projMatrix, out ShadowSplitData splitData
            );
            splitData.shadowCascadeBlendCullingFactor = 
                Mathf.Max(0f, 0.8f - shadowSettings.directional.cascadeFade);
            SetDirectionalShadowCascadeData(i, splitData.cullingSphere, resolution);
            buffer.SetViewport(rect);
            buffer.SetViewProjectionMatrices(viewMatrix, projMatrix);
            buffer.SetGlobalDepthBias(0f, light.slopeScaleBias);
            ExecuteBuffer();
            ShadowDrawingSettings settings = new ShadowDrawingSettings (
                cullingResults, light.visibleLightIndex
            ) { splitData = splitData };
            context.DrawShadows(ref settings);
            buffer.SetGlobalDepthBias(0f, 0f);
            ExecuteBuffer();
            dirShadowMatrices[subIndex] = 
                GetShadowMapMatrix(viewMatrix, projMatrix, rect, size);
        }
    }

    private void SelectShaderMultiCompile(string[] keywords, int index) {
        for (int i = 0; i < keywords.Length; i++) {
            if (i == index) {
                buffer.EnableShaderKeyword(keywords[i]);
            } else {
                buffer.DisableShaderKeyword(keywords[i]);
            }
        }
    }

    private void RenderDirectionalShadows() {
        int size = (int)shadowSettings.directional.atlasSize;
        buffer.GetTemporaryRT(
            dirShadowAtlasId, size, size, 32,
            FilterMode.Bilinear, RenderTextureFormat.Shadowmap);
        buffer.SetRenderTarget(dirShadowAtlasId, 
            RenderBufferLoadAction.DontCare, RenderBufferStoreAction.Store);
        buffer.ClearRenderTarget(true, false, Color.clear);
        buffer.SetGlobalFloat(shadowPancakingId, 1.0f);
        buffer.BeginSample(bufferName);
        ExecuteBuffer();
        for(int i = 0; i < shadowedDirectionalLightCount; i++) {
            RenderDirectionalShadows(i);
        }
        buffer.SetGlobalInt(
            dirShadowCascadeCountId, shadowSettings.directional.cascadeCount);
        buffer.SetGlobalVectorArray(
            dirShadowCascadeCullingSpheresId, dirShadowCascadeCullingSpheres);
        buffer.SetGlobalVectorArray(
            dirShadowCascadeDataid, dirShadowCascadeDatas);
        buffer.SetGlobalMatrixArray(dirShadowMatricesId, dirShadowMatrices);
        SelectShaderMultiCompile(
            dirShadowPcfFilterKeywords, (int)shadowSettings.directional.filterMode - 1);
        SelectShaderMultiCompile(
            dirShadowCascadeBlendKeywords, (int)shadowSettings.directional.cascadeBlendMode - 1);
        buffer.EndSample(bufferName);
        ExecuteBuffer();
    }

    private Vector4 GetOtherShadowData(
        Rect rect, Matrix4x4 projMatrix, ShadowedOtherLight light) {
        float resolution = Mathf.Min(rect.width, rect.height);
        float texelSize = 2.0f / (resolution * projMatrix.m00);
        float filterSize = texelSize * ((float)shadowSettings.other.filterMode + 1);
        int size = (int)shadowSettings.other.atlasSize;
        float border = 0.5f / size;
        return new Vector4(
            light.normalBias * filterSize * Mathf.Sqrt(2), 
            rect.x / size + border, 
            rect.y / size + border, resolution / size - 2 * border);
    }

    private float GetFovBias(float resolution, float normalBias) {
        float filterRadius = (float)shadowSettings.other.filterMode + 1;
        float filterSize = 2.0f * filterRadius / resolution;
        float bias = normalBias * filterSize * Mathf.Sqrt(2);
        float fovBias = Mathf.Atan(1f + bias  + filterSize);
        fovBias = fovBias * Mathf.Rad2Deg * 2f - 90f;
        return fovBias;
    }

    private void RenderPointShadows(int index) {
        int size = (int)shadowSettings.other.atlasSize;
        var light = shadowedOtherLights[index];

        for (int i = 0; i < 6; i++) {
            Rect rect = GetShadowMapRect(index + i, shadowedOtherLightCount, size);
            int resolution = (int)Mathf.Min(rect.width, rect.height);
            cullingResults.ComputePointShadowMatricesAndCullingPrimitives(
                light.visibleLightIndex, (CubemapFace)i, 
                GetFovBias(resolution, light.normalBias), out Matrix4x4 viewMatrix, 
                out Matrix4x4 projMatrix, out ShadowSplitData splitData);
			viewMatrix.m11 = -viewMatrix.m11;
			viewMatrix.m12 = -viewMatrix.m12;
			viewMatrix.m13 = -viewMatrix.m13;
            var settings = new ShadowDrawingSettings (
                cullingResults, light.visibleLightIndex
            ) { splitData = splitData };
            
            buffer.SetViewport(rect);
            buffer.SetViewProjectionMatrices(viewMatrix, projMatrix);
            buffer.SetGlobalDepthBias(0f, light.slopeScaleBias);
            ExecuteBuffer();
            context.DrawShadows(ref settings);
            otherShadowDatas[index + i] = GetOtherShadowData(rect, projMatrix, light);
            otherShadowMatrices[index + i] = GetShadowMapMatrix(
                viewMatrix, projMatrix, rect, size);
        }
        buffer.SetGlobalDepthBias(0f, 0f);
        ExecuteBuffer();
    }

    private void RenderSpotShadows(int index) {
        int size = (int)shadowSettings.other.atlasSize;
        var light = shadowedOtherLights[index];
        Rect rect = GetShadowMapRect(index, shadowedOtherLightCount, size);
        int resolution = (int)Mathf.Min(rect.width, rect.height);
        cullingResults.ComputeSpotShadowMatricesAndCullingPrimitives(
            light.visibleLightIndex, out Matrix4x4 viewMatrix,
            out Matrix4x4 projMatrix, out ShadowSplitData splitData);
        ShadowDrawingSettings settings = new ShadowDrawingSettings (
            cullingResults, light.visibleLightIndex
        ) { splitData = splitData };
        buffer.SetViewport(rect);
        buffer.SetViewProjectionMatrices(viewMatrix, projMatrix);
        buffer.SetGlobalDepthBias(0f, light.slopeScaleBias);
        ExecuteBuffer();
        context.DrawShadows(ref settings);
        buffer.SetGlobalDepthBias(0f, 0f);
        ExecuteBuffer();
        otherShadowDatas[index] = GetOtherShadowData(rect, projMatrix, light);
        otherShadowMatrices[index] = GetShadowMapMatrix(
            viewMatrix, projMatrix, rect, size);
    }

    private void RenderOtherShadows() {
        int size = (int)shadowSettings.other.atlasSize;
        buffer.GetTemporaryRT(
            otherShadowAtlasId, size, size, 32,
            FilterMode.Bilinear, RenderTextureFormat.Shadowmap);
        buffer.SetRenderTarget(otherShadowAtlasId,
            RenderBufferLoadAction.DontCare, RenderBufferStoreAction.Store);
        buffer.ClearRenderTarget(true, false, Color.clear);
        buffer.SetGlobalFloat(shadowPancakingId, 0.0f);
        buffer.BeginSample(bufferName);
        ExecuteBuffer();
        for (int i = 0; i < shadowedOtherLightCount;) {
            if (shadowedOtherLights[i].isPoint) {
                RenderPointShadows(i);
                i += 6;
            } else {
                RenderSpotShadows(i);
                i += 1;
            }
        }
        buffer.SetGlobalMatrixArray(otherShadowMatricesId, otherShadowMatrices);
        buffer.SetGlobalVectorArray(otherShadowDataId, otherShadowDatas);
        SelectShaderMultiCompile(otherShadowPcfFilterKeywords, (int)shadowSettings.other.filterMode - 1);
        buffer.EndSample(bufferName);
        ExecuteBuffer();
    }

    public void Render() {
        buffer.BeginSample(bufferName);
        SelectShaderMultiCompile(shadowMaskKeywords, 
            useShadowMask ? (QualitySettings.shadowmaskMode 
            == ShadowmaskMode.Shadowmask ? 0 : 1) : -1);
        buffer.SetGlobalVector(
            shadowAtlasSizeID, new Vector4(
                (int)shadowSettings.directional.atlasSize,
                1.0f / (int)shadowSettings.directional.atlasSize,
                (int)shadowSettings.other.atlasSize,
                1.0f / (int)shadowSettings.other.atlasSize)
        );
        buffer.SetGlobalVector(shadowFadeId, new Vector4(
            1 / shadowSettings.distanceFade, 1 / shadowSettings.maxDistance,
            1 / (1 - Mathf.Pow(1 - shadowSettings.directional.cascadeFade, 2)), 0.0f));
        buffer.EndSample(bufferName);
        ExecuteBuffer();

        if (shadowedDirectionalLightCount > 0) {
            RenderDirectionalShadows();
        } else {
            buffer.GetTemporaryRT(
                dirShadowAtlasId, 1, 1, 32, 
                FilterMode.Bilinear, RenderTextureFormat.Shadowmap);
            ExecuteBuffer();
        }
        if (shadowedOtherLightCount > 0) {
            RenderOtherShadows();
        } else {
            buffer.SetGlobalTexture(otherShadowAtlasId, dirShadowAtlasId);
        }
    }

    public void Cleanup() {
        buffer.ReleaseTemporaryRT(dirShadowAtlasId);
        if (shadowedOtherLightCount > 0) {
            buffer.ReleaseTemporaryRT(otherShadowAtlasId);
        }
        ExecuteBuffer();
    }
}
