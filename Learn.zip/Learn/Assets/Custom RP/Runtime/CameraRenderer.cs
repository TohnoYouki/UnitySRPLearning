using UnityEngine;
using UnityEngine.Rendering;

public partial class CameraRenderer {

    private const string bufferName = "Render Camera";

    private CommandBuffer buffer = 
        new CommandBuffer { name = bufferName };

    private Camera camera;

    private ScriptableRenderContext context;

    private CullingResults cullingResult;

    private Lighting lighting = new Lighting();

    private PostFxStack postFxStack = new PostFxStack();

    private bool useHDR = false;

    private static ShaderTagId unlitShaderTagId = 
        new ShaderTagId("SRPDefaultUnlit");

    private static ShaderTagId litShaderTagId = 
        new ShaderTagId("CustomLit");

    private static int frameBufferId = 
        Shader.PropertyToID("_CameraFrameBuffer");

	private void ExecuteBuffer () {
		context.ExecuteCommandBuffer(buffer);
		buffer.Clear();
	}

    private bool Cull(float maxShadowDistance) {
        ScriptableCullingParameters param;
        if (camera.TryGetCullingParameters(out param)) {
            param.shadowDistance = Mathf.Min(maxShadowDistance, camera.farClipPlane);
            cullingResult = context.Cull(ref param);
            return true;
        }
        return false;
    }

    private void Setup() {
        context.SetupCameraProperties(camera);
        CameraClearFlags flags = camera.clearFlags;
        if (postFxStack.IsActive) {
            if (flags > CameraClearFlags.Color) {
                flags = CameraClearFlags.Color;
            }
            buffer.GetTemporaryRT(
                frameBufferId, camera.pixelWidth, camera.pixelHeight,
                32, FilterMode.Bilinear, 
                useHDR ? RenderTextureFormat.DefaultHDR : RenderTextureFormat.Default);
            buffer.SetRenderTarget(frameBufferId, 
                RenderBufferLoadAction.DontCare, RenderBufferStoreAction.Store);
        }
        buffer.ClearRenderTarget(flags <= CameraClearFlags.Depth, 
                                 flags == CameraClearFlags.Color, 
                                 flags == CameraClearFlags.Color ? 
                                 camera.backgroundColor.linear : Color.clear);
    }

    private void DrawVisibleGeometry(
        bool useDynamicBatching, bool useGPUInstancing, bool useLightPerObject) {
        var sortSetting = new SortingSettings(camera) {
            criteria = SortingCriteria.CommonOpaque
        };
        var lightPerObjectFlags = useLightPerObject ? PerObjectData.LightData 
            | PerObjectData.LightIndices : PerObjectData.None;
        var drawingSetting = new DrawingSettings(unlitShaderTagId, sortSetting) {
            enableDynamicBatching = useDynamicBatching,
            enableInstancing = useGPUInstancing,
            perObjectData = PerObjectData.Lightmaps 
                          | PerObjectData.LightProbe 
                          | PerObjectData.LightProbeProxyVolume
                          | PerObjectData.ShadowMask
                          | PerObjectData.OcclusionProbe
                          | PerObjectData.OcclusionProbeProxyVolume
                          | PerObjectData.ReflectionProbes
                          | lightPerObjectFlags
        };
        drawingSetting.SetShaderPassName(1, litShaderTagId);

        var filteringSetting = new FilteringSettings(RenderQueueRange.opaque);
        context.DrawRenderers(
            cullingResult, ref drawingSetting, ref filteringSetting);

        context.DrawSkybox(camera);

        sortSetting.criteria = SortingCriteria.CommonTransparent;
        filteringSetting.renderQueueRange = RenderQueueRange.transparent;
        context.DrawRenderers(
            cullingResult, ref drawingSetting, ref filteringSetting);
    }
    
    public void Render(ScriptableRenderContext context, Camera camera,
                       bool useDynamicBatching, bool useGPUInstancing, 
                       bool useLightPerObject, bool useHDR,
                       ShadowSettings shadowSettings, PostFXSettings postFXSettings) {
        this.camera = camera;
        this.context = context;
        this.useHDR = useHDR && camera.allowHDR;
        PrepareForSceneWindow();
        if (!Cull(shadowSettings.maxDistance)) { return; }

        buffer.BeginSample(bufferName);
        ExecuteBuffer();
        lighting.Setup(context, cullingResult, shadowSettings, useLightPerObject);
        postFxStack.Setup(context, camera, postFXSettings, useHDR);
        buffer.EndSample(bufferName);
        Setup();

        buffer.BeginSample(bufferName);
        ExecuteBuffer();
        DrawVisibleGeometry(useDynamicBatching, useGPUInstancing, useLightPerObject);
        DrawUnsupportedShaders();
        DrawGizmosBeforeFX();
        if (postFxStack.IsActive) {
            postFxStack.Render(frameBufferId);
        }
        DrawGizmosAfterFX();

        Cleanup();
        buffer.EndSample(bufferName);
        ExecuteBuffer();
        context.Submit();
    }

    public void Cleanup() {
        lighting.Cleanup();
        if (postFxStack.IsActive) {
            buffer.ReleaseTemporaryRT(frameBufferId);
        }
    }
}
