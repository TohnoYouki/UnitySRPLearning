using UnityEngine;
using UnityEngine.Rendering;

public partial class CustomRenderPipeline : RenderPipeline {

    private CameraRenderer renderer = new CameraRenderer();
    
    private bool useDynamicBatching, useGPUInstancing, useLightPerObject, useHDR;
    
    private ShadowSettings shadowSettings;

    private PostFXSettings postFXSettings;
    
    public CustomRenderPipeline(
        bool useDynamicBatching, bool useGPUInstancing, bool useSRPBatcher, bool useHDR,
        bool useLightPerObject, ShadowSettings shadowSettings, PostFXSettings postFXSettings) {
        this.useDynamicBatching = useDynamicBatching;
        this.useGPUInstancing = useGPUInstancing;
        this.useHDR = useHDR;
        this.useLightPerObject = useLightPerObject;
        this.shadowSettings = shadowSettings;
        this.postFXSettings = postFXSettings;
        GraphicsSettings.useScriptableRenderPipelineBatching = useSRPBatcher;
        GraphicsSettings.lightsUseLinearIntensity = true;
        InitializeForEditor();
    }
    
    protected override void Render(ScriptableRenderContext context, Camera[] cameras) {
        foreach (Camera camera in cameras) {
            renderer.Render(context, camera, 
                useDynamicBatching, useGPUInstancing, 
                useLightPerObject, useHDR, 
                shadowSettings, postFXSettings);
        }
    }
}