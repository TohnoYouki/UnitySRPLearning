using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

public partial class CameraRenderer {

    private partial void DrawGizmosBeforeFX();

    private partial void DrawGizmosAfterFX();
    
    private partial void PrepareForSceneWindow();
    
    private partial void DrawUnsupportedShaders();

#if UNITY_EDITOR
    
    private static ShaderTagId[] legacyShaderTagIds = {
        new ShaderTagId("Always"),
        new ShaderTagId("ForwardBase"),
        new ShaderTagId("PrepassBase"),
        new ShaderTagId("Vertex"),
        new ShaderTagId("VertexLMRGBM"),
        new ShaderTagId("VertexLM")
    };
    
    private static Material errorMaterial;

    private partial void DrawGizmosBeforeFX() {
        if (Handles.ShouldRenderGizmos()) {
            context.DrawGizmos(camera, GizmoSubset.PreImageEffects);
        }
    }
    
    private partial void DrawGizmosAfterFX() {
        if (Handles.ShouldRenderGizmos()) {
            context.DrawGizmos(camera, GizmoSubset.PostImageEffects);
        }
    }
    
    private partial void PrepareForSceneWindow() {
        if (camera.cameraType == CameraType.SceneView) {
            ScriptableRenderContext.EmitWorldGeometryForSceneView(camera);
        }
    }
    
    private partial void DrawUnsupportedShaders() {
        if (errorMaterial is null) {
            errorMaterial = new Material(Shader.Find("Hidden/InternalErrorShader"));
        }
        var drawingSetting = new DrawingSettings(
            legacyShaderTagIds[0], new SortingSettings(camera)) {
            overrideMaterial = errorMaterial
        };
        for (int i = 1; i < legacyShaderTagIds.Length; i++) {
            drawingSetting.SetShaderPassName(i, legacyShaderTagIds[i]);
        }
        var filteringSetting = FilteringSettings.defaultValue;
        context.DrawRenderers(
            cullingResult, ref drawingSetting, ref filteringSetting);
    }
    
#endif
}