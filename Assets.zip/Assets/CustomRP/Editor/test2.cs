using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(SkyBoxIBLGenerator))]
public class test2 : Editor {
    public override void OnInspectorGUI() {
        base.OnInspectorGUI();

        bool create = false;
        create = GUILayout.Button("Create");
        if (create) {
            var generator = target as SkyBoxIBLGenerator;
            generator.DiffuseConvolution();
        }
    }
}