using UnityEngine;
using UnityEngine.Rendering;

public partial class CustomRenderPipeline : RenderPipeline {

    private CameraRenderer renderer = new CameraRenderer();
    
    private bool useLightPerObject, useHDR;

    private BatchingSettings batchingSettings;
    
    private ShadowSettings shadowSettings;

    private PostFxSettings postFxSettings;
    
    public CustomRenderPipeline(
        bool useHDR, bool useLightPerObject, 
        BatchingSettings batchingSettings, 
        ShadowSettings shadowSettings, PostFxSettings postFxSettings) {
        this.useHDR = useHDR;
        this.useLightPerObject = useLightPerObject;
        this.batchingSettings = batchingSettings;
        this.shadowSettings = shadowSettings;
        this.postFxSettings = postFxSettings;
        GraphicsSettings.useScriptableRenderPipelineBatching = batchingSettings.useSRPBatcher;
        GraphicsSettings.lightsUseLinearIntensity = true;
        //InitializeForEditor();
    }
    
    protected override void Render(ScriptableRenderContext context, Camera[] cameras) {
        foreach (Camera camera in cameras) {
            renderer.Render(context, camera,  useLightPerObject, useHDR, 
                batchingSettings, shadowSettings, postFxSettings);
        }
    }
}