using System;
using UnityEngine;
using UnityEngine.Rendering;

public partial class CameraRenderer {

    private const string bufferName = "Render Camera";

    private CommandBuffer buffer = 
        new CommandBuffer { name = bufferName };

    public class RenderingData
    {
        public bool useHDR;
        public bool useLightPerObject;
        public Camera camera;
        public ScriptableRenderContext context;
        public CullingResults cullingResults;

        public void ExecuteBuffer(CommandBuffer buffer) {
            context.ExecuteCommandBuffer(buffer);
            buffer.Clear();
        }

        public struct BufferSample : IDisposable
        {
            private CommandBuffer buffer;
            private RenderingData renderingData;

            public BufferSample(RenderingData renderingData, CommandBuffer buffer) {
                this.buffer = buffer;
                this.renderingData = renderingData;
                buffer.BeginSample(buffer.name);
                renderingData.ExecuteBuffer(buffer);
            }

            public void Dispose() {
                buffer.EndSample(buffer.name);
                renderingData.ExecuteBuffer(buffer);
            }
        }

        public BufferSample AllocateSample(CommandBuffer buffer) {
            return new BufferSample(this, buffer);
        }
    }

    private RenderingData renderingData;

    //private Lighting lighting = new Lighting();

    private PostFxStack postFxStack = new PostFxStack();
    
    private static ShaderTagId unlitShaderTagId = 
        new ShaderTagId("SRPDefaultUnlit");

    private static ShaderTagId litShaderTagId = 
        new ShaderTagId("CustomLit");

    private static int frameBufferId = 
        Shader.PropertyToID("_CameraFrameBuffer");
    
    private bool Cull(float maxShadowDistance) {
        ScriptableCullingParameters param;
        Camera camera = renderingData.camera;
        ScriptableRenderContext context = renderingData.context;
        if (camera.TryGetCullingParameters(out param)) {
            param.shadowDistance = Mathf.Min(
                maxShadowDistance, camera.farClipPlane);
            renderingData.cullingResults = context.Cull(ref param);
            return true;
        }
        return false;
    }

    private void Setup() {
        Camera camera = renderingData.camera;
        ScriptableRenderContext context = renderingData.context;
        context.SetupCameraProperties(camera);
        CameraClearFlags flags = camera.clearFlags;
        
        if (postFxStack.IsActive) {
            if (flags > CameraClearFlags.Color) {
                flags = CameraClearFlags.Color;
            }
            buffer.GetTemporaryRT(
                frameBufferId, camera.pixelWidth, camera.pixelHeight,
                32, FilterMode.Bilinear, 
                renderingData.useHDR ? 
                RenderTextureFormat.DefaultHDR : RenderTextureFormat.Default);
            buffer.SetRenderTarget(frameBufferId, 
                RenderBufferLoadAction.DontCare, RenderBufferStoreAction.Store);
        }
        buffer.ClearRenderTarget(flags <= CameraClearFlags.Depth, 
                                 flags == CameraClearFlags.Color, 
                                 flags == CameraClearFlags.Color ? 
                                 camera.backgroundColor.linear : Color.clear);
    }
    
    private void DrawVisibleGeometry(BatchingSettings batchingSettings) {
        Camera camera = renderingData.camera;
        ScriptableRenderContext context = renderingData.context;
        var sortSetting = new SortingSettings(camera) {
            criteria = SortingCriteria.CommonOpaque
        };
        
        var lightPerObjectFlags = renderingData.useLightPerObject ? 
            PerObjectData.LightData | PerObjectData.LightIndices 
            : PerObjectData.None;
        var drawingSetting = new DrawingSettings(unlitShaderTagId, sortSetting) {
            enableDynamicBatching = batchingSettings.useDynamicBatching,
            enableInstancing = batchingSettings.useGPUInstancing,
            perObjectData = PerObjectData.Lightmaps 
                          | PerObjectData.LightProbe 
                          | PerObjectData.LightProbeProxyVolume
                          | PerObjectData.ShadowMask
                          | PerObjectData.OcclusionProbe
                          | PerObjectData.OcclusionProbeProxyVolume
                          | PerObjectData.ReflectionProbes
                          | lightPerObjectFlags
        };
        drawingSetting.SetShaderPassName(1, litShaderTagId);

        var filteringSetting = new FilteringSettings(RenderQueueRange.opaque);
        context.DrawRenderers(
            renderingData.cullingResults, 
            ref drawingSetting, ref filteringSetting);

        context.DrawSkybox(camera);
        
        sortSetting.criteria = SortingCriteria.CommonTransparent;
        filteringSetting.renderQueueRange = RenderQueueRange.transparent;
        context.DrawRenderers(
            renderingData.cullingResults, 
            ref drawingSetting, ref filteringSetting);
    }
    
    public void Render(ScriptableRenderContext context, Camera camera,
                       bool useLightPerObject, bool useHDR,
                       BatchingSettings batchingSettings,
                       ShadowSettings shadowSettings, 
                       PostFxSettings postFxSettings) {

        renderingData = new RenderingData {
            useHDR = useHDR && camera.allowHDR, 
            useLightPerObject = useLightPerObject,
            camera = camera, context = context };

        PrepareForSceneWindow();
        if (!Cull(shadowSettings.maxDistance)) { return; }

        using (var sampler = renderingData.AllocateSample(buffer)) {
            //lighting.Setup(context, cullingResult, shadowSettings, useLightPerObject);
            postFxStack.Setup(renderingData, postFxSettings);
        }

        Setup();

        using (var sampler = renderingData.AllocateSample(buffer)) {
            DrawVisibleGeometry(batchingSettings);
            DrawUnsupportedShaders();
            DrawGizmos(GizmoSubset.PreImageEffects);
            if (postFxStack.IsActive) {
                postFxStack.Render(frameBufferId);
            }
            DrawGizmos(GizmoSubset.PostImageEffects);
            Cleanup();
        }
        context.Submit();
    }

    public void Cleanup() {
        //lighting.Cleanup();
        if (postFxStack.IsActive) {
            buffer.ReleaseTemporaryRT(frameBufferId);
        }
    }
}
