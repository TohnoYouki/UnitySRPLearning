using UnityEngine;
using UnityEngine.Rendering;

[System.Serializable]
public struct BatchingSettings {
    public bool useDynamicBatching;
    public bool useGPUInstancing;
    public bool useSRPBatcher;
}

[CreateAssetMenu(menuName = "Rendering/Custom Render Pipeline")]
public class CustomRenderPipelineAsset : RenderPipelineAsset {
    [SerializeField]
    private BatchingSettings batching = new BatchingSettings {
        useDynamicBatching = true,
        useGPUInstancing = true,
        useSRPBatcher = true
    };

    public BatchingSettings Batching => batching;

    [SerializeField]
    public bool useHDR = true, useLightPerObject = true;
    
    [SerializeField]
    public ShadowSettings shadowsSettings = default;

    [SerializeField]
    public PostFxSettings postFxSettings = default;
    
    protected override RenderPipeline CreatePipeline() {
        return new CustomRenderPipeline(useHDR, useLightPerObject, 
            batching, shadowsSettings, postFxSettings);
    }
}