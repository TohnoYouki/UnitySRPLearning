using UnityEditor;
using UnityEngine;

public partial class PostFxStack
{
    private partial void ApplySceneViewState();

#if UNITY_EDITOR

    private partial void ApplySceneViewState() {
        Camera camera = renderingData.camera;
        if (camera.cameraType == CameraType.SceneView &&
            !SceneView.currentDrawingSceneView.sceneViewState.showImageEffects) {
            settings = null;
        }
    }

#endif
}
