using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

public partial class CameraRenderer {

    private partial void DrawGizmos(GizmoSubset subset);
    
    private partial void PrepareForSceneWindow();
    
    private partial void DrawUnsupportedShaders();

#if UNITY_EDITOR
    
    private static ShaderTagId[] legacyShaderTagIds = {
        new ShaderTagId("Always"),
        new ShaderTagId("ForwardBase"),
        new ShaderTagId("PrepassBase"),
        new ShaderTagId("Vertex"),
        new ShaderTagId("VertexLMRGBM"),
        new ShaderTagId("VertexLM")
    };
    
    private static Material errorMaterial;

    private partial void DrawGizmos(GizmoSubset subset) {
        if (Handles.ShouldRenderGizmos()) {
            renderingData.context.DrawGizmos(renderingData.camera, subset);
        }
    }
    
    private partial void PrepareForSceneWindow() {
        Camera camera = renderingData.camera;
        if (camera.cameraType == CameraType.SceneView) {
            ScriptableRenderContext.EmitWorldGeometryForSceneView(camera);
        }
    }
    
    private partial void DrawUnsupportedShaders() {
        if (errorMaterial is null) {
            errorMaterial = new Material(Shader.Find("Hidden/InternalErrorShader"));
        }
        var drawingSetting = new DrawingSettings(
            legacyShaderTagIds[0], new SortingSettings(renderingData.camera)) {
            overrideMaterial = errorMaterial
        };
        for (int i = 1; i < legacyShaderTagIds.Length; i++) {
            drawingSetting.SetShaderPassName(i, legacyShaderTagIds[i]);
        }
        var filteringSetting = FilteringSettings.defaultValue;
        renderingData.context.DrawRenderers(
            renderingData.cullingResults, ref drawingSetting, ref filteringSetting);
    }
    
#endif
}