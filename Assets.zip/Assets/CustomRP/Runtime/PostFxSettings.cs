using UnityEngine;

[CreateAssetMenu(menuName = "Rendering/Custom PostFx Settings")]
public class PostFxSettings : ScriptableObject {
    [SerializeField]
    public Shader shader = default;

    [System.NonSerialized]
    private Material material;

    [System.Serializable]
    public struct BloomSettings {
        public const int maxBloomPyramidLevels = 16;

        public enum Mode { Additive, Scattering }

        public Mode mode;

        [Range(0.05f, 0.95f)]
        public float scatter;

        [Range(0f, (float)maxBloomPyramidLevels)]
        public int maxIterations;

        [Min(1f)]
        public int downscaleLimit;

        public bool bicubicUpsampling;

        public bool fadeFireflies;

        [Min(0f)]
        public float intensity;

        [Min(0f)]
        public float threshold;

        [Range(0f, 1f)]
        public float thresholdKnee;
    }

    [System.Serializable]
    public struct ToneMappingSettings {
        public enum Mode { None, Reinhard, Neutral, ACES }

        public Mode mode;
    }

    [SerializeField]
    private BloomSettings bloom = new BloomSettings {
        mode = BloomSettings.Mode.Scattering,
        scatter = 0.7f,
        maxIterations = 16,
        downscaleLimit = 2,
        bicubicUpsampling = true,
        fadeFireflies = true,
        intensity = 1.0f,
        threshold = 1.0f,
        thresholdKnee = 0.1f
    };

    public BloomSettings Bloom => bloom;

    [SerializeField]
    private ToneMappingSettings toneMapping = new ToneMappingSettings {
        mode = ToneMappingSettings.Mode.Neutral
    };

    public ToneMappingSettings ToneMapping => toneMapping;

    public Material Material {
        get {
            if (material == null && shader != null) {
                material = new Material(shader);
                material.hideFlags = HideFlags.HideAndDontSave;
            }
            return material;
        }
    }
}
